﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tesseract.Tests.Leptonica
{
    [TestFixture]
    public class LoadFromFileTests
    {
        [Test]
        public void CanLoadJpeg()
        {
            // TODO :)
        }
    }
}
