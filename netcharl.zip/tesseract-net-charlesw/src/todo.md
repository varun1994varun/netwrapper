Task Num	| Task													| Status
------------|-------------------------------------------------------|------------------------------------------
			| Tesseract - Engine									| Done
			| Leptonica - Pix support								| Done
			| Leptonica - Load \ Save images						| Implemented - no regression tests (yet)
			| Tesseract - Result Iteration							| Done
			| Tesseract - Embed unmanaged dlls						| Pending
			| General - Release alpha and code base on GitHub		| Pending
			| Tesseract - Regression tests							| Pending
			| Leptonica - Scanned img prep funcs					| Pending
			| Tesseract - Create sample app							| Pending
			| Tesseract - Dictionary???								| Pending
