﻿using System;

namespace Tesseract
{

    public enum EngineMode : int
    {
        TesseractOnly = 0, 
        LstmOnly,
         TesseractAndLstm,
         Default,
        CubeOnly, 
 		TesseractAndCube
    }
}