﻿#region Using directives

using System;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

#endregion

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("TesseractOcr")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("TesseractOcr")]
[assembly: AssemblyCopyright("Copyright 2012")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// This sets the default COM visibility of types in the assembly to invisible.
// If you need to expose a type to COM, use [ComVisible(true)] on that type.
[assembly: ComVisible(false)]

// Ensure internals are visible to the test assembly so we can test them too.
[assembly: InternalsVisibleTo("Tesseract.Tests, PublicKey=002400000480000094000000060200000024000052534131000400000100010091e49b91628b757460eda92ee4b99ab34a51a71efec18a6f9c63cf82eb50341dc6013349315d9eee7caae220c4e4ac07dbbaa18de97ff0768ecc66e158c8a83c2f664f4ca8bce01066b65b89d8ce4aac0a4b967e7260f92cc0390253fd5ce7e3674803d028d9792584a7843b3f7b7202b9e003e0baec83f77a144bddafea02d9")]

// Versioning is handled by AssemblyVersionInfo.cs
