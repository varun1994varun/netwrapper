﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Tesseract.Tests.Console
{
    class Class1
    {
        public static void Main(string[] args)
        {
            Tesseract.TesseractEngine ocr = new Tesseract.TesseractEngine(@"\tessdata", "eng");
            System.Console.WriteLine(ocr.Version.ToString());
            Pix p = Pix.LoadFromFile(@"\phototest.tif");
            Page page=ocr.Process(p);
            System.Console.WriteLine(page.GetText());

        }
    }
}
