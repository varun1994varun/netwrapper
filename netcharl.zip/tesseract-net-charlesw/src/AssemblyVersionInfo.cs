﻿#region Using directives

using System;
using System.Reflection;
using System.Runtime.InteropServices;

#endregion

// Tesseract is versioned using semantic version (http://semver.org/) and takes form:
//
// Major.Minor.Patch

[assembly: AssemblyVersion("3.0.2.0")]
[assembly: AssemblyFileVersion("3.0.2.0")]